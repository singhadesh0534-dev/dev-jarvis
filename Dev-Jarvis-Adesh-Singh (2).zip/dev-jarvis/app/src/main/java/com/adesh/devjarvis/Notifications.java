package com.adesh.devjarvis;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;

public class Notifications extends NotificationListenerService {
    static Notifications current;
    @Override public void onListenerConnected() { current=this; }
    @Override public void onListenerDisconnected() { current=null; }
    @Override public void onDestroy() { current=null; super.onDestroy(); }
    static String read() {
        if (current==null) return "Enable notification access first.";
        StringBuilder result=new StringBuilder();
        try {
            StatusBarNotification[] items=current.getActiveNotifications();
            for (int i=0; i<Math.min(items.length, 8); i++) {
                Notification n=items[i].getNotification();
                result.append(n.extras.getCharSequence(Notification.EXTRA_TITLE, "")).append(": ").append(n.extras.getCharSequence(Notification.EXTRA_TEXT, "")).append(". ");
            }
        } catch (SecurityException e) { return "Notification access unavailable."; }
        return result.length()==0 ? "No active notifications." : result.toString();
    }
}
