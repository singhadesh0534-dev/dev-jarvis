package com.adesh.devjarvis;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import android.app.AlertDialog;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    private TextView output;
    private EditText input, endpoint, model;
    private SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayDeque<String> queue=new ArrayDeque<>();
    private final ArrayList<JSONObject> history=new ArrayList<>();
    private boolean voiceReady=false, aiBusy=false;
    private int generation=0;
    private boolean ttsInitialized=false;
    private String lockedEngine;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("dev", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(5,14,24));
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,48,28,32); root.setBackgroundColor(Color.rgb(5,14,24)); scroll.addView(root);
        TextView title=label("DEV JARVIS",30); title.setTextColor(Color.CYAN); root.addView(title);
        root.addView(label("PERSONAL ASSISTANT • ADESH SINGH",13));
        root.addView(label("Voice • Device actions • Optional local AI",16));
        output=label("Ready, Adesh. Type a command or tap Speak.\nSay help for examples.",18); output.setPadding(0,26,0,26); output.setTextIsSelectable(true); root.addView(output);
        input=field("Command / Hindi ya Hinglish mein bolo", ""); root.addView(input);
        button(root,"RUN COMMAND",v -> run(input.getText().toString()));
        button(root,"SPEAK / BOLO",v -> listen());
        button(root,"STOP ACTIONS & VOICE",v -> {generation++; queue.clear(); handler.removeCallbacksAndMessages(null); if(tts!=null)tts.stop(); output.setText("Stopped. In-flight AI replies discarded.");});
        button(root,"ENABLE SCREEN CONTROL",v -> open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button(root,"ENABLE NOTIFICATION ACCESS",v -> open(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        button(root,"CHOOSE / LOCK VOICE",v -> chooseVoice());
        button(root,"VOICE SETTINGS",v -> open(new Intent("com.android.settings.TTS_SETTINGS")));
        root.addView(label("OPTIONAL AI • YOUR OLLAMA SERVER",16));
        root.addView(label("Only chat text is sent to this server. Screen and notifications stay on this phone. HTTP is supported for trusted local networks.",14));
        endpoint=field("http://YOUR-PC-IP:11434",prefs.getString("endpoint","")); root.addView(endpoint);
        model=field("Ollama model name",prefs.getString("model","qwen2.5:3b")); root.addView(model);
        button(root,"SAVE AI SETTINGS",v -> {prefs.edit().putString("endpoint",endpoint.getText().toString().trim()).putString("model",model.getText().toString().trim()).apply(); history.clear(); say("AI settings saved. Conversation cleared.");});
        button(root,"HELP",v -> say(help()));
        setContentView(scroll);
        lockedEngine=prefs.getString("voice_engine", Settings.Secure.getString(getContentResolver(), "tts_default_synth"));
        if(lockedEngine==null || lockedEngine.isEmpty()) {
            output.setText("Enable a TTS engine in Android settings, then reopen Dev Jarvis.");
        } else {
            tts=new TextToSpeech(this,status -> new Handler(Looper.getMainLooper()).post(() -> {
                if(isDestroyed())return;
                if(status!=TextToSpeech.SUCCESS){voiceUnavailable();return;}
                ttsInitialized=true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){}
                    @Override public void onDone(String id){}
                    @Override public void onError(String id){runOnUiThread(() -> {if(!isDestroyed())voiceUnavailable();});}
                });
                if(prefs.contains("voice_name")) {
                    if(!applyLockedVoice())voiceUnavailable();
                } else output.setText("Adesh, tap CHOOSE / LOCK VOICE once to select your permanent voice.");
            }),lockedEngine);
        }
    }
    private TextView label(String text,int size){TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(211,235,244)); return t;}
    private EditText field(String hint,String value){EditText e=new EditText(this); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); e.setHint(hint); e.setText(value); e.setSingleLine(false); return e;}
    private void button(LinearLayout root,String text,View.OnClickListener listener){Button b=new Button(this); b.setText(text); b.setOnClickListener(listener); root.addView(b);}
    private void voiceUnavailable(){
        voiceReady=false;
        output.append("\nVoice unavailable. Restore your saved TTS engine/voice or choose a voice manually. No automatic voice replacement.");
    }
    private boolean engineInstalled(){
        if(tts==null)return false;
        for(TextToSpeech.EngineInfo e:tts.getEngines())if(e.name.equals(lockedEngine))return true;
        return false;
    }
    private boolean applyLockedVoice(){
        voiceReady=false;
        if(!ttsInitialized || !engineInstalled())return false;
        String name=prefs.getString("voice_name", "");
        Set<Voice> voices=tts.getVoices();
        if(voices==null)return false;
        for(Voice v:voices)if(v.getName().equals(name)){
            if(tts.setVoice(v)!=TextToSpeech.SUCCESS)return false;
            Voice actual=tts.getVoice();
            if(actual==null || !actual.getName().equals(name))return false;
            if(tts.setSpeechRate(0.92f)!=TextToSpeech.SUCCESS || tts.setPitch(0.88f)!=TextToSpeech.SUCCESS)return false;
            voiceReady=true;return true;
        }
        return false;
    }
    private void chooseVoice(){
        if(!ttsInitialized || !engineInstalled()){voiceUnavailable();return;}
        Set<Voice> available=tts.getVoices();
        ArrayList<Voice> voices=new ArrayList<>();
        if(available!=null)for(Voice v:available)if(!v.isNetworkConnectionRequired())voices.add(v);
        voices.sort(Comparator.comparing((Voice v) -> !v.getLocale().equals(Locale.UK)).thenComparing(Voice::getName));
        if(voices.isEmpty()){output.setText("No offline voices found. Install voice data in Android TTS settings, then restart the app.");return;}
        String[] names=new String[voices.size()];
        for(int i=0;i<voices.size();i++)names[i]=voices.get(i).getLocale().toLanguageTag()+" • "+voices.get(i).getName();
        new AlertDialog.Builder(this).setTitle("Choose one fixed offline voice")
            .setItems(names,(dialog,index) -> {
                if(tts!=null)tts.stop();
                prefs.edit().putString("voice_engine",lockedEngine).putString("voice_name",voices.get(index).getName()).apply();
                say("Ready, Adesh Singh. I am Dev Jarvis. This is your saved voice.");
            }).setNegativeButton("Cancel",null).show();
    }
    private void say(String text){
        output.setText(text);
        if(!applyLockedVoice()){voiceUnavailable();return;}
        if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"dev")!=TextToSpeech.SUCCESS)voiceUnavailable();
    }
    private boolean open(Intent intent){try{startActivity(intent); return true;}catch(ActivityNotFoundException|SecurityException e){say("This action is unavailable on this phone.");return false;}}
    private void listen(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},9);return;}
        if(tts!=null)tts.stop();
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Adesh, Dev Jarvis sun raha hai");
        try{startActivityForResult(i,10);}catch(ActivityNotFoundException e){say("Install or enable an Android speech recognition service. You can still type commands.");}
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==9 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)listen();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==10 && result==RESULT_OK && data!=null){ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(words!=null&&!words.isEmpty()){input.setText(words.get(0));run(words.get(0));}}}
    private String help(){return "Commands: open YouTube / YouTube kholo; home; back; recents; scroll down; scroll up; tap Search; type hello; notifications; time; battery; settings; wifi; bluetooth; volume up; volume down; search weather in Delhi; dial +911234567890.\nSequence: open YouTube then tap Search then type space documentary.\nUse 'ask your question' for optional AI chat. Screen actions need Accessibility. Sequences stop on reported failure, but app loading can require separate commands. Return to Dev Jarvis to speak again.";}
    private void run(String raw){
        if(raw.trim().isEmpty())return;
        generation++; handler.removeCallbacksAndMessages(null);queue.clear();
        if(raw.toLowerCase(Locale.ROOT).startsWith("ask ")){chat(raw.substring(4));return;}
        String[] steps=raw.split("(?i)\\s+(?:then|phir|फिर)\\s+");
        if(steps.length>12){say("Please use at most twelve steps per command.");return;}
        Collections.addAll(queue,steps); next();
    }
    private void next(){if(queue.isEmpty())return;String step=queue.remove();boolean ok=action(step);if(!ok){queue.clear();return;}if(!queue.isEmpty())handler.postDelayed(this::next,1800);}
    private boolean action(String raw){
        String c=raw.trim().toLowerCase(Locale.ROOT).replaceFirst("^(?:dev jarvis|jarvis|देव जार्विस|जार्विस)[, ]*", "");
        ControlService s=ControlService.current;
        try{
            if(c.equals("help")||c.equals("मदद")){say(help());return true;}
            if(c.equals("time")||c.contains("कितने बजे")||c.equals("samay")){say("Adesh, it is "+DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()));return true;}
            if(c.equals("battery")||c.equals("बैटरी")){BatteryManager b=(BatteryManager)getSystemService(BATTERY_SERVICE);say("Battery is "+b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)+" percent.");return true;}
            if(c.equals("notifications")||c.equals("नोटिफिकेशन")){say(Notifications.read());return Notifications.current!=null;}
            if(c.equals("settings")||c.equals("सेटिंग"))return open(new Intent(Settings.ACTION_SETTINGS));
            if(c.equals("wifi")||c.equals("वाईफाई"))return open(new Intent(Settings.ACTION_WIFI_SETTINGS));
            if(c.equals("bluetooth")||c.equals("ब्लूटूथ"))return open(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            if(c.equals("volume up")||c.equals("volume down")){android.media.AudioManager a=(android.media.AudioManager)getSystemService(AUDIO_SERVICE);a.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,c.endsWith("up")?1:-1,android.media.AudioManager.FLAG_SHOW_UI);return true;}
            if(c.startsWith("search "))return open(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(raw.trim().substring(7)))));
            if(c.startsWith("dial ")){String number=c.substring(5).replaceAll("[ ()-]","");if(!number.matches("\\+?[0-9]{3,15}")){say("Please provide a phone number.");return false;}return open(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+number)));}
            if(c.startsWith("open ")||c.endsWith(" kholo")||c.endsWith(" खोलो")){
                String name=c.startsWith("open ")?c.substring(5):c.replaceFirst(" (kholo|खोलो)$","");
                Map<String,String> aliases=new HashMap<>();aliases.put("यूट्यूब","youtube");aliases.put("व्हाट्सएप","whatsapp");aliases.put("क्रोम","chrome");name=aliases.getOrDefault(name,name);
                Intent launcher=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                ArrayList<ResolveInfo> matches=new ArrayList<>();
                for(ResolveInfo r:getPackageManager().queryIntentActivities(launcher,0))if(r.loadLabel(getPackageManager()).toString().equalsIgnoreCase(name))matches.add(r);
                if(matches.size()==1){ResolveInfo r=matches.get(0);return open(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name)));}
                say(matches.isEmpty()?"App not found. Use its exact installed name.":"Multiple matching apps found. Open the intended app manually.");return false;
            }
            boolean screen=c.equals("home")||c.equals("back")||c.equals("recents")||c.startsWith("tap ")||c.startsWith("type ")||c.equals("scroll down")||c.equals("scroll up");
            if(screen){
                if(s==null){say("Enable Dev Jarvis under Android Accessibility settings first.");return false;}
                boolean done;
                if(c.equals("home"))done=s.performGlobalAction(2);
                else if(c.equals("back"))done=s.performGlobalAction(1);
                else if(c.equals("recents"))done=s.performGlobalAction(3);
                else if(c.startsWith("tap "))done=s.click(c.substring(4));
                else if(c.startsWith("type "))done=s.type(raw.trim().substring(5));
                else done=s.scroll(c.endsWith("down"));
                if(!done)say("Action failed: "+raw+". Check the visible screen; sequence stopped.");
                else output.setText("Android accepted action: "+raw);
                return done;
            }
            say("Command not recognised. Say help, or start with 'ask' for AI chat.");return false;
        }catch(Exception e){say("Action unavailable; sequence stopped.");return false;}
    }
    private void chat(String prompt){
        String base=prefs.getString("endpoint",""), selected=prefs.getString("model","qwen2.5:3b");
        try{URI uri=new URI(base);if(!Arrays.asList("http","https").contains(uri.getScheme())||uri.getHost()==null)throw new Exception();}catch(Exception e){say("Configure your Ollama server first. Device commands work without it.");return;}
        if(aiBusy){say("An AI request is still running. Please try again when it finishes.");return;}
        aiBusy=true;int ticket=generation;output.setText("Thinking…");
        ArrayList<JSONObject> previous=new ArrayList<>(history);
        worker.submit(() -> {
            HttpURLConnection conn=null;
            try{
                JSONArray messages=new JSONArray();messages.put(new JSONObject().put("role","system").put("content","You are Dev Jarvis, Adesh Singh's personal assistant. Speak concise Hindi/Hinglish or English matching the user, with a calm British butler manner. You are chat only: you cannot execute actions here. Never claim to have controlled the device. Explain uncertainty honestly."));
                for(JSONObject m:previous)messages.put(m);
                JSONObject user=new JSONObject().put("role","user").put("content",prompt);messages.put(user);
                JSONObject payload=new JSONObject().put("model",selected).put("stream",false).put("messages",messages).put("options",new JSONObject().put("num_predict",512));
                conn=(HttpURLConnection)new URL(base.replaceAll("/+$","")+"/api/chat").openConnection();conn.setRequestMethod("POST");conn.setConnectTimeout(10000);conn.setReadTimeout(90000);conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json");
                try(OutputStream out=conn.getOutputStream()){out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
                if(conn.getResponseCode()!=200)throw new IOException("Server returned HTTP "+conn.getResponseCode());
                StringBuilder body=new StringBuilder();try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null){body.append(line);if(body.length()>1000000)throw new IOException("Response too large");}}
                String answer=new JSONObject(body.toString()).getJSONObject("message").getString("content");
                runOnUiThread(() -> {aiBusy=false;if(ticket!=generation||isDestroyed())return;try{history.add(user);history.add(new JSONObject().put("role","assistant").put("content",answer));while(history.size()>12)history.remove(0);}catch(JSONException ignored){}say(answer);});
            }catch(Exception e){runOnUiThread(() -> {aiBusy=false;if(ticket==generation&&!isDestroyed())say("AI connection failed. Check server address, network and installed model. Device commands remain available.");});}
            finally{if(conn!=null)conn.disconnect();}
        });
    }
    @Override public void onDestroy(){generation++;handler.removeCallbacksAndMessages(null);worker.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
