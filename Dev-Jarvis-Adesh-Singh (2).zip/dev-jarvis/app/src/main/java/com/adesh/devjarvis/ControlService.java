package com.adesh.devjarvis;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class ControlService extends AccessibilityService {
    public static ControlService current;
    @Override protected void onServiceConnected() { current = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { current = null; super.onDestroy(); }
    public boolean click(String label) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(label);
        for (AccessibilityNodeInfo node : nodes) {
            CharSequence text = node.getText(), desc = node.getContentDescription();
            if (!(text != null && label.equalsIgnoreCase(text.toString())) && !(desc != null && label.equalsIgnoreCase(desc.toString()))) continue;
            for (int i=0; node != null && i<5; i++, node=node.getParent())
                if (node.isClickable() && node.isEnabled()) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        return false;
    }
    public boolean type(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (node == null || !node.isEditable() || node.isPassword()) return false;
        Bundle args = new Bundle(); args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }
    public boolean scroll(boolean forward) { return scrollNode(getRootInActiveWindow(), forward); }
    private boolean scrollNode(AccessibilityNodeInfo n, boolean forward) {
        if (n == null) return false;
        if (n.isScrollable() && n.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true;
        for (int i=0; i<n.getChildCount(); i++) if (scrollNode(n.getChild(i),forward)) return true;
        return false;
    }
}
