# Dev Jarvis — Adesh Singh

Android prototype, Java, Android 8+. No paid API dependency. This is source code, not a tested APK or a finished autonomous AI agent.

## Build an APK

PC: install Android Studio, open this folder, install SDK 35 when prompted, let Gradle sync, then use Build > Generate App Bundles or APKs > Generate APKs. Select JDK 17 or newer. With Gradle 8.9 installed: `gradle assembleDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Phone-only alternative: put this entire project, including `.github`, into your GitHub repository. Actions > Build Android APK > Run workflow. Download the Dev-Jarvis-APK artifact from the completed run, unzip, then install app-debug.apk. GitHub account/Actions availability and usage limits apply. Nothing has been uploaded to GitHub by this project creator.

## First launch

1. Install the APK and open Dev Jarvis.
2. Tap SPEAK and allow microphone access. If no speech service exists, install/enable one or use typed commands. Recognition may use the service provider's internet servers; this app cannot guarantee offline speech.
3. For screen actions, use ENABLE SCREEN CONTROL and enable Dev Jarvis. Some Android versions require App info > menu > Allow restricted settings for sideloaded accessibility apps. Grant only if you trust your built APK. Accessibility reads the active window only during requested actions; no screen data is sent to AI.
4. Enable notification access only if you want notifications read aloud. Content, including sensitive notifications, may be spoken nearby. No notification history is persisted.
5. In Android TTS settings install a British English offline voice. In Dev Jarvis tap CHOOSE / LOCK VOICE and select it once. The app persists the engine package and exact voice name, and re-applies that voice, pitch 0.88 and rate 0.92 before every utterance. It requests the saved engine on restart, even if the Android default changes. Only offline voices appear in the picker. If the saved voice cannot be applied, speech stops with an on-screen message instead of the app selecting another voice. You can manually change it via the same picker. Engine-internal fallback behavior and changes to voice data in engine updates are outside app control: this is not a guarantee of identical audio forever. No actor recording, exact movie voice, or ElevenLabs API is included. Hindi pronunciation depends on the chosen voice.

## Commands

`open YouTube`, `YouTube kholo`, `यूट्यूब खोलो`, `home`, `back`, `recents`, `scroll down`, `scroll up`, `tap Search`, `type hello`, `notifications`, `time`, `battery`, `settings`, `wifi`, `bluetooth`, `volume up`, `volume down`, `search weather Delhi`, `dial +911234567890`.

Sequence: `open YouTube then tap Search then type space documentary`. Up to 12 actions with 1.8 seconds between steps. Button names must match the visible labels exactly; UI language matters. A failed action stops the sequence. Android accepting an action is NOT proof the intended app task succeeded. Slow apps need separate commands. Typing replaces the focused input's contents. Password fields are excluded. Calls open the dialer; settings open their Android screens. Not every screen exposes accessible controls.

Dev Jarvis is tap-to-talk, with no background microphone, wake word, overlay or lock-screen bypass. After opening another app, return to Dev Jarvis to issue more commands. Sequences can continue while its Activity remains alive; Android may terminate the process. Stop clears pending steps and speech but cannot undo completed actions.

## Optional AI conversation, no paid API

On your own computer, install Ollama and run `ollama pull qwen2.5:3b`. Serve Ollama on your trusted LAN using its OLLAMA_HOST setting (e.g. 0.0.0.0:11434), and allow the port through your local firewall for your phone only. Do not expose an unauthenticated Ollama server to the public internet. Enter `http://YOUR-COMPUTER-LAN-IP:11434` in Dev Jarvis, save, then type `ask explain black holes in Hindi`.

The computer must stay on. No computer/server is included or configured. Text conversation is sent to the configured server; the last six exchanges are retained only in app memory. Cleartext HTTP is permitted for local servers; use HTTPS when available. Model quality and latency depend on that server's hardware. AI chat does not execute phone actions or plan arbitrary autonomous workflows in this version. Built-in actions use deterministic command matching. No on-device LLM is bundled.

## Verification status

Manifest and resource XML parsed successfully. Java compilation and syntax validation were unavailable (no Android SDK or Java compiler). Android SDK download was not completed in the authoring environment, so Gradle compilation, APK installation, speech, permissions and device behavior have NOT been verified. Test on your phone before relying on automation.

## Device test checklist

- Deny microphone: typed commands still work. Grant it: speech service launches.
- Accessibility disabled: screen actions explain the missing permission.
- Run time/battery; open an installed app; test home/back.
- Open an editable test field, focus it, then test type via a sequence. Check tap and scroll on accessible controls.
- Unknown or missing button stops remaining steps. Stop cancels pending steps.
- Notification access disabled/enabled; inspect spoken content.
- Missing/unreachable AI server gives an error without disabling device commands.
- Close/reopen app and check saved server settings and cleared conversation.

## Scope

This foundation does not provide unlimited Android control, root, arbitrary complex task completion, general AI vision, reminders, messaging integrations, biometric unlock, or movie-level intelligence. Those require further implementation and device testing. The app contains no analytics or advertising SDK. Free software does not remove hardware/network costs or third-party usage limits.

## Fixed voice regression checks (device testing pending)

Select a voice and restart the app: the same engine and voice ID must remain selected. Change the system default TTS voice and confirm Dev Jarvis still requests its saved voice. Remove its voice data or disable its saved engine: speech should stop and show a message, without selecting a replacement. Check Hindi and English replies keep the same voice ID. Test without network after voice data is installed. App data clearing/uninstall resets the saved selection. Engine updates can change the sound associated with a voice ID.
